let connection = new TikTokIOConnection();

const params = (new URL(document.location)).searchParams;
const login = params.get("login")


Vue.createApp({
    data() {
        return {
            login: login,
            uniqueId: (login === 'dwins.all') ? '' : login,
            liveStatus: null,
            liveInterval: null,

            panel: {
                show: true
            },

            word: '',
            crossword: '',
            hiddenLetters: [0, 3],

            wordTimeCount: 60,
            wordTimer: null,

            wordBlackList: [],

            guessed: [
                // {
                //     username: 'null',
                //     avatar: null,
                //     message: null,
                //     count: null,
                // }
            ],
            gift: [
                {
                    username: null,
                    avatar: null,
                }
            ],
            sponsorAmount: 1,
            sponsorTimeCount: 0,
            sponsorTimer: null,

            words: [],

            language: {
                active: 'uk',
                original: 'ru',
                languages: [
                    {
                        code: 'uk',
                        name: 'Українська'
                    },
                    {
                        code: 'ru',
                        name: 'Русский'
                    },
                    {
                        code: 'en',
                        name: 'English'
                    }
                ],
            },
            i18n: [
                {
                    original: 'Угадай слово',
                    uk: 'Вгадай слово',
                    en: 'Guess the word'
                },
                {
                    original: '1я буква слова',
                    uk: '1ша літера слова',
                    en: '1st letter of the word'
                },
                {
                    original: 'Подарок минимум за',
                    uk: 'Подарунок мінімум за',
                    en: 'Gift for at least'
                },
                {
                    original: 'Пиар',
                    uk: 'Піар',
                    en: 'PR'
                },
                {
                    original: 'Угадал(а) слово:',
                    uk: 'Вгадав(ла) слово:',
                    en: 'Guessed the word:'
                },
                {
                    original: 'Лидеры:',
                    uk: 'Лідери:',
                    en: 'Leaders:'
                },
                {
                    original: 'Аукцион:',
                    uk: 'Аукціон:',
                    en: 'Auction:'
                },
                {
                    original: 'Кол-во слов:',
                    uk: 'Кількість слів:',
                    en: 'Number of words:'
                },
                {
                    original: 'Угадало 0 человек',
                    uk: 'Вгадало 0 людей',
                    en: '0 people guessed'
                },
                {
                    original: 'Спасибо за подарок!',
                    uk: 'Дякую за подарунок!',
                    en: 'Thanks for the gift!'
                },
                {
                    original: 'Подпишись на спонсора',
                    uk: 'Підпишись на спонсора',
                    en: 'Subscribe to sponsor'
                },
                {
                    original: 'Лучше подарок = дольше пиар',
                    uk: 'Краще подарунок = довше піар',
                    en: 'Better gift = longer PR'
                },
                {
                    original: 'Блок экрана:',
                    uk: 'Блок экрану:',
                    en: 'Screen block:'
                },
                {
                    original: 'Язык:',
                    uk: 'Мова:',
                    en: 'Language:'
                },
                {
                    original: 'Чтобы запустить такой же эфир, переходи по ссылке в профиле',
                    uk: 'Щоб запустити такий самий ефір, переходь за посиланням у профілі',
                    en: 'To start the same broadcast, follow the link in the profile'
                },
                {
                    original: 'Для разблокировки нужно:',
                    uk: 'Для розблокування потрібно:',
                    en: 'To unlock you need:'
                },
                {
                    original: 'лайков',
                    uk: 'лайків',
                    en: 'likes'
                },
                {
                    original: 'или',
                    uk: 'або',
                    en: 'or'
                },
                {
                    original: 'подписок/репостов',
                    uk: 'підписок/репостів',
                    en: 'subscriptions/reposts'
                },
                {
                    original: 'Не подключено',
                    uk: 'Не підключено',
                    en: 'Not connected'
                },
                {
                    original: 'Подключиться',
                    uk: 'Підключитись',
                    en: 'connect'
                },
                {
                    original: 'Стандарт',
                    en: 'Standard'
                },
                {
                    original: 'Видео - Градиент',
                    uk: 'Відео - Градієнт',
                    en: 'Video - Gradient'
                },
                {
                    original: 'Відео - Мыло',
                    uk: 'Відео - Мило',
                    en: 'Video - Soap'
                },
                {
                    original: 'Слово:',
                    en: 'Word:'
                },
                {
                    original: 'Изменить слово',
                    uk: 'Змінити слово',
                    en: 'Change the word'
                },
                {
                    original: 'Блок экрана:',
                    uk: 'Блок екрану:',
                    en: 'Screen block:'
                },
                {
                    original: 'Фон:',
                    en: 'Background:'
                },
                {
                    original: 'Скрыть',
                    uk: 'Приховати',
                    en: 'Hide'
                },
                {
                    original: 'Показать',
                    uk: 'Показати',
                    en: 'Show'
                },
                {
                    original: 'Автоматический блок экрана:',
                    uk: 'Автоматичний блок екрану:',
                    en: 'Automatic block screen:'
                },
                {
                    original: 'Включено',
                    uk: 'Увімкнено',
                    en: 'On'
                },
                {
                    original: 'Выключено',
                    uk: 'Вимкнено',
                    en: 'Off'
                },
                {
                    original: 'Отображать каждые(сек):',
                    uk: 'Відображати кожні(сек):',
                    en: 'Display every(sec):'
                },
                {
                    original: 'Отобразится через:',
                    uk: 'Відобразиться через:',
                    en: 'Displayed via:'
                },
                {
                    original: 'Скрыть',
                    ru: 'Скрыть',
                    uk: 'Сховати',
                    en: 'Hide'
                },
                {
                    original: 'Показать',
                    ru: 'Показать',
                    uk: 'Показати',
                    en: 'Show'
                },
                {
                    original: 'сек',
                    en: 'sec'
                },
            ],

            lock: {
                enable: true,

                default: {
                    // timerCount: 5,
                    timerCount: 60 * 5,
                    // умножает количество пользователей на:
                    likeCount: 30,
                    // делит количетво пользователей на:
                    subscribeCount: 10,
                },

                likeCount: 0,
                subscribeCount: 0,
                timer: null,
                timerCount: 0,
            },

            bg: {
                active: 0,
                files: [
                    {
                        name: 'Стандарт',
                        type: 'none',
                    },
                    {
                        name: 'Видео - Градиент',
                        type: 'video',
                        url: '/assets/videos/bg/Background - 4422.mp4',
                        volume: false
                    },
                    {
                        name: 'Відео - Мыло',
                        type: 'video',
                        url: '/assets/videos/bg/soap-cubes-3.mp4',
                        volume: true
                    }
                ]
            },
            usersCount: 0
        }
    },
    mounted() {
        this.loadWords();

        this.startWordTimer()


        // комментарий в чат
        connection.on('chat', (msg) => {
            this.addComment(msg)
        })
        // Подарки в чат
        connection.on('gift', (data) => {
            this.addGift(data)
            // this.addGiftSuper(data)
        })


        connection.on('setUniqueIdFailed', (errorMessage) => {
            this.liveStatus = errorMessage
            this.stopLockTimer()
        })
        connection.on('streamEnd', () => {
            this.liveStatus = 'Stream ended.';
            this.stopLockTimer()
        })
        // ioConnection.on('setUniqueIdSuccess', (state) => {
        //     console.log('setUniqueIdSuccess')
        //     // this.liveInterval = setInterval(() => {
        //     // }, 60000)
        //     if (this.liveStatus !== 'Live') {
        //         this.stopLockTimer()
        //         this.startLockTimer()
        //     }
        //     this.liveStatus = 'Live'
        // })


        connection.on('like', (msg) => {
            if (typeof msg.likeCount === 'number') {
                if (this.lock.timerCount === 0) {
                    this.lock.likeCount -= msg.likeCount
                    if (this.lock.likeCount <= 0) {
                        this.startLockTimer()
                    }
                }
            }
        })


        connection.on('social', (data) => {
            // let color = data.displayType.includes('follow') ? '#ff005e' : '#2fb816';
            if (this.lock.timerCount === 0) {
                this.lock.subscribeCount -= 1
                if (this.lock.subscribeCount <= 0) {
                    this.startLockTimer()
                }
            }

        })

        connection.on('roomUser', (msg) => {
            if (typeof msg.viewerCount === 'number') {
                this.usersCount = msg.viewerCount;
            }
        })

    },
    destroyed() {
        this.stopWordTimer()
    },
    methods: {
        // Добавление комментария
        addComment(msg) {
            if (msg.comment.toLowerCase() === this.word.toLowerCase()) {
                this.addGuessedUser(msg.uniqueId, msg.profilePictureUrl, msg.comment)
                this.newWord()
            }
        },
        // Добавление пользвателя в список угадавших слово
        addGuessedUser(username, avatar, message) {

            let globalUserKey = false
            for (let userKey = 0; userKey < this.guessed.length; userKey++) {
                if (this.guessed[userKey].username === username) {
                    this.guessed[userKey].number++
                    this.guessed[userKey].message = message
                    globalUserKey = userKey
                    this.guessed.splice(0, 0, this.guessed.splice(globalUserKey, 1)[0])
                    break;
                }
            }
            if (globalUserKey === false) {
                this.guessed.unshift({
                    username: username,
                    avatar: avatar,
                    message: message,
                    number: 1
                })
            }
        },
        // Добавление спонсора и оторажение буквы
        addGift(data) {
            if (data.gift && data.repeatCount) {
                const orderDiamond = data.diamondCount * data.repeatCount
                if (orderDiamond >= this.sponsorAmount) {
                    this.addGiftUser(data.uniqueId, data.profilePictureUrl)
                    this.stopSponsorTimer()
                    this.startSponsorTimer(orderDiamond)
                }
            }
            if (data.gift && data.repeatCount && data.diamondCount >= 1) {
                if (this.hiddenLetters.includes(0)) {
                    this.showHiddenLetters(0)
                }
            }
        },
        // Добавление пользвателя в список дарителей
        addGiftUser(username, avatar) {
            this.gift[0] = {
                username: username,
                avatar: avatar,
            }
        },
        // addGiftSuper(data) {
        //     if (data.extendedGiftInfo.diamond_count >= 10) {
        //         this.addGiftSuperUser(data.uniqueId, data.profilePictureUrl)
        //     }
        // },
        // addGiftSuperUser(username, avatar) {
        //     this.giftSuper[0] = {
        //         username: username,
        //         avatar: avatar,
        //     }
        // },
        loadWords() {
            const language = this.language.active
            fetch(`./data/words-${language}.json`)
                .then(response => {
                    return response.json();
                })
                .then(jsondata => {
                    this.words = jsondata
                    this.newWord()
                });

        },
        newWord() {
            this.wordTimeCount = 60

            this.word = ''
            this.hiddenLetters = [0, 3]

            const randomWordIndex = getRandomInt(this.words.length - 1)
            this.word = this.words[randomWordIndex]
            this.generateCrosswordWord()
        },
        generateCrosswordWord() {
            this.crossword = ''
            for (let i = 0; i < this.word.length; i++) {
                if (this.hiddenLetters.includes(i)) {
                    this.crossword += '*'
                } else {
                    this.crossword += this.word[i]
                }
            }
        },
        showHiddenLetters(index) {
            if (this.hiddenLetters.includes(index)) {
                this.hiddenLetters.splice(this.hiddenLetters.indexOf(index), 1)
            } else {
                this.hiddenLetters.push(index)
            }
            this.generateCrosswordWord()
        },

        //    Timer
        startWordTimer() {
            this.wordTimer = setInterval(() => {
                if (this.lock.timerCount > 0) {
                    this.wordTimeCount--
                }
            }, 1000)
        },
        stopWordTimer() {
            clearTimeout(this.wordTimer)
        },
        //    Timer
        startLockTimer() {
            this.lock.timerCount = this.lock.default.timerCount

            this.lock.timer = setInterval(() => {
                if (this.lock.enable === true && this.lock.timerCount > 0) {
                    this.lock.timerCount--
                    if (this.lock.timerCount === 0) this.stopLockTimer()
                }
            }, 1000)
        },
        stopLockTimer() {
            this.lock.likeCount = this.usersCount * this.lock.default.likeCount
            this.lock.subscribeCount = Math.ceil(this.usersCount / this.lock.default.subscribeCount)
            clearTimeout(this.lock.timer)
        },
        toggleLockTimer() {
            if (this.lock.timerCount === 0) {
                this.stopLockTimer()
                if (this.lock.enable) {
                    this.startLockTimer()
                } else {
                    this.lock.timerCount = this.lock.default.timerCount
                }
            } else {
                this.stopLockTimer()
                this.lock.timerCount = 0
            }
        },
        startSponsorTimer(amount) {
            this.sponsorTimeCount = amount * 60
            this.sponsorAmount = Math.ceil(this.sponsorTimeCount / 60) + 1
            this.sponsorTimer = setInterval(() => {
                this.sponsorTimeCount--
                this.sponsorAmount = Math.ceil(this.sponsorTimeCount / 60) + 1
            }, 1000)
        },
        stopSponsorTimer() {
            clearTimeout(this.sponsorTimer)
        },
        connect() {
            this.liveStatus = 'Loading...';
            if (this.uniqueId !== '') {
                connection.connect(this.uniqueId, {
                    enableExtendedGiftInfo: true
                }).then(state => {
                    if (this.liveStatus !== 'Live') {
                        this.stopLockTimer()
                        this.startLockTimer()
                    }
                    this.liveStatus = 'Live';
                }).catch(errorMessage => {
                    this.liveStatus = errorMessage;
                })
            } else {
                this.liveStatus = 'No username entered';
            }
        },
        t(original) {
            if (this.language.active === this.language.original) {
                return original
            }
            const translate = this.i18n.find(item => {
                return item.original === original
            })
            if (translate) {
                if (translate[this.language.active]) {
                    return translate[this.language.active]
                } else {
                    return original
                }
            } else {
                return original
            }
        }
    },
    watch: {
        wordTimeCount(time) {
            if (time === 0) {
                this.newWord()
            }
        },
        sponsorTimeCount(time) {
            if (time === 0) {

                this.stopSponsorTimer()
                this.gift[0] = {
                    username: null,
                    avatar: null,
                }
            }
        }
    },
    computed: {
        orderedGuessed: function () {
            let guessed = JSON.parse(JSON.stringify(this.guessed));
            return guessed.sort(function (a, b) {
                if (a.number > b.number) {
                    return -1;
                }
                if (a.number < b.number) {
                    return 1;
                }
                return 0;
            });
        }
    }

}).mount('#app')


function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}


// function sanitize(text) {
//     return text.replace(/</g, '&lt;')
// }
//
// function updateRoomStats() {
//     $('#roomStats').html(`Viewers: <b>${viewerCount.toLocaleString()}</b> Likes: <b>${likeCount.toLocaleString()}</b> Earned Diamonds: <b>${diamondsCount.toLocaleString()}</b>`)
// }
//
// function generateUsernameLink(data) {
//     return `<a class="usernamelink" href="https://www.tiktok.com/@${data.uniqueId}" target="_blank">${data.uniqueId}</a>`;
// }
//
// function isPendingStreak(data) {
//     return data.gift.gift_type === 1 && data.gift.repeat_end === 0;
// }

// Комментарии в чат
// function addChatItem(color, data, text, summarize) {
//     let container = $('.chatcontainer');
//
//     if (container.find('div').length > 500) {
//         container.find('div').slice(0, 200).remove();
//     }
//
//     container.find('.temporary').remove();;
//
//     container.append(`
//         <div class=${summarize ? 'temporary' : 'static'}>
//             <img class="miniprofilepicture" src="${data.profilePictureUrl}">
//             <span>
//                 <b>${generateUsernameLink(data)}:</b>
//                 <span style="color:${color}">${sanitize(text)}</span>
//             </span>
//         </div>
//     `);
//
//     container.stop();
//     container.animate({
//         scrollTop: container[0].scrollHeight
//     }, 400);
// }

// Добавление подарка
// function addGiftItem(data) {
//     let container = $('.giftcontainer');
//
//     if (container.find('div').length > 200) {
//         container.find('div').slice(0, 100).remove();
//     }
//
//     let streakId = data.userId.toString() + '_' + data.giftId;
//
//     let html = `
//         <div data-streakid=${isPendingStreak(data) ? streakId : ''}>
//             <img class="miniprofilepicture" src="${data.profilePictureUrl}">
//             <span>
//                 <b>${generateUsernameLink(data)}:</b> <span>${data.extendedGiftInfo.describe}</span><br>
//                 <div>
//                     <table>
//                         <tr>
//                             <td><img class="gifticon" src="${(data.extendedGiftInfo.icon || data.extendedGiftInfo.image).url_list[0]}"></td>
//                             <td>
//                                 <span>Name: <b>${data.extendedGiftInfo.name}</b> (ID:${data.giftId})<span><br>
//                                 <span>Repeat: <b style="${isPendingStreak(data) ? 'color:red' : ''}">x${data.gift.repeat_count.toLocaleString()}</b><span><br>
//                                 <span>Diamonds: <b>${(data.extendedGiftInfo.diamond_count * data.gift.repeat_count).toLocaleString()}</b><span>
//                             </td>
//                         </tr>
//                     </tabl>
//                 </div>
//             </span>
//         </div>
//     `;
//
//     let existingStreakItem = container.find(`[data-streakid='${streakId}']`);
//
//     if (existingStreakItem.length) {
//         existingStreakItem.replaceWith(html);
//     } else {
//         container.append(html);
//     }
//
//     container.stop();
//     container.animate({
//         scrollTop: container[0].scrollHeight
//     }, 800);
// }

// Control events
// ioConnection.on('setUniqueIdSuccess', (state) => {
//     // reset stats
//     viewerCount = 0;
//     likeCount = 0;
//     diamondsCount = 0;
//     updateRoomStats();
//     $('#stateText').text(`Connected to roomId ${state.roomId}`);
//
// })
//
// ioConnection.on('setUniqueIdFailed', (errorMessage) => {
//     $('#stateText').text(errorMessage);
// })
//
// ioConnection.on('streamEnd', () => {
//     $('#stateText').text('Stream ended.');
// })
//
// // viewer stats
// ioConnection.on('roomUser', (msg) => {
//     if (typeof msg.viewerCount === 'number') {
//         viewerCount = msg.viewerCount;
//         updateRoomStats();
//     }
// })
//
// // like stats
// ioConnection.on('like', (msg) => {
//     if (typeof msg.likeCount === 'number') {
//         addChatItem('#447dd4', msg, msg.label.replace('{0:user}', '').replace('likes', `${msg.likeCount} likes`))
//     }
//
//     if (typeof msg.totalLikeCount === 'number') {
//         likeCount = msg.totalLikeCount;
//         updateRoomStats();
//     }
// })


// // Chat events, (вступили в чат)
// let joinMsgDelay = 0;
// ioConnection.on('member', (msg) => {
//     let addDelay = 250;
//     if (joinMsgDelay > 500) addDelay = 100;
//     if (joinMsgDelay > 1000) addDelay = 0;
//
//     joinMsgDelay += addDelay;
//
//     setTimeout(() => {
//         joinMsgDelay -= addDelay;
//         addChatItem('#21b2c2', msg, 'joined', true);
//     }, joinMsgDelay);
// })


// добавление подарка
// ioConnection.on('gift', (data) => {
//     addGiftItem(data);
//
//     if (!isPendingStreak(data) && data.extendedGiftInfo.diamond_count > 0) {
//         diamondsCount += (data.extendedGiftInfo.diamond_count * data.gift.repeat_count);
//         updateRoomStats();
//     }
// })

// // поделиться и подписка
// ioConnection.on('social', (data) => {
//     let color = data.displayType.includes('follow') ? '#ff005e' : '#2fb816';
//     addChatItem(color, data, data.label.replace('{0:user}', ''));
// })